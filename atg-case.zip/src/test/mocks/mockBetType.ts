const mockBetType = {
    betType: "V75",
    results: [
    {
    id: "V75_2023-11-05_5_6",
    tracks: [
    {
    id: 5,
    name: "Solvalla"
    }
    ],
    totalToWin: 1731917700,
startTime: "2023-11-05T15:00:16",
addOns: [
"boost"
]
    },
    {
    id: "V75_2023-11-04_78_5",
    tracks: [
    {
    id: 78,
    name: "Bjerke"
    }
    ],
    totalToWin: 6229572000,
startTime: "2023-11-04T16:21:14",
addOns: [
"boost"
]
    },
    ]
    }

    export default mockBetType